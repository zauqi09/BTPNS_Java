package com.company;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;

public class PrintData extends Thread{
    ArrayList<String[]> siswa;
    PrintData(ArrayList<String[]> listsiswa){
        this.siswa=listsiswa;
    }
    public void run(){
            for (String[] i : siswa) {
                for(int j=0; j<i.length; j++ ){
                    if (j==0){
                        System.out.println(String.format("Nama : "+i[j]));
                    } else if (j==1){
                        System.out.println(String.format("Nilai Fisika : "+i[j]));
                    } else if (j==2){
                        System.out.println(String.format("Nilai Biologi : "+i[j]));
                    } else if (j==3){
                        System.out.println(String.format("Nilai Kimia : "+i[j]+"\n"));
                    }
                }
            }
    }
}
