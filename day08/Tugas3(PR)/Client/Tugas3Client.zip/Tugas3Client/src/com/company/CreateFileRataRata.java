package com.company;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;

public class CreateFileRataRata extends Thread{
    ArrayList<String[]> siswa;
    CreateFileRataRata(ArrayList<String[]> listsiswa){
        this.siswa=listsiswa;
    }
    public void run(){
        try{
            FileWriter writer = new FileWriter("FileRata2.txt");
            BufferedWriter buffer = new BufferedWriter(writer);
            buffer.write("Nama,Rata2");
            buffer.write("\n");
            //save line
            for (String[] i : siswa) {
                double avg =(Double.parseDouble(i[1])+Double.parseDouble(i[2])+Double.parseDouble(i[3]))/3;
                buffer.write(String.format(""+i[0]+","+Double.toString(avg)));
                buffer.write("\n");
            }
            buffer.close();
            writer.close();
        } catch (Exception e){
            e.printStackTrace();
        }
    }
}
