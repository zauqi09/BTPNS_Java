class Nomor1 {
    int ID;
    String nama;
    String jeniskelamin;

    public Nomor1(int newID, String newNama, String newJK){
        ID = newID;
        nama = newNama;
        jeniskelamin = newJK;
    }
}