public class Nomor1run {
    public static void main(String[] args) {
        Nomor1 mhs = new Nomor1(1301164392,"Fuad Zauqi Nur","Laki-laki");
    }
}
