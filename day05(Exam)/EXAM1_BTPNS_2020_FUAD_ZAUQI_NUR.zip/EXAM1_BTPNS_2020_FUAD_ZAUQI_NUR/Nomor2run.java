public class Nomor2run {
    public static void main(String[] args) {
        Nomor2 mobil = new Nomor2(2010,"Avanza",0);
        mobil.TambahKecepatan(120);
        mobil.KurangiKecepatan(50);
    }
}
